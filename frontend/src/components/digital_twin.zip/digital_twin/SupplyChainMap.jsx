import { useEffect } from 'react';
import { MapContainer, TileLayer, Polyline, CircleMarker, Popup, useMap } from 'react-leaflet';
import { corridors as fallbackCorridors, sites as fallbackSites } from '../../data/demoData';
import { riskColor } from '../../utils/mapConfig';
import 'leaflet/dist/leaflet.css';

const colors = { port: '#fbbf24', refinery: '#60a5fa', reserve: '#c084fc' };

// Leaflet sizes its tile grid and projects every marker/route using the
// container's pixel size at the moment it mounts, and this map sits inside
// a CSS grid column whose final size may not be settled yet at mount time.
// Calling invalidateSize() once things settle keeps both tiles and vector
// layers correctly positioned if that ever happens again.
function FixMapSize() {
  const map = useMap();
  useEffect(() => {
    const t = setTimeout(() => map.invalidateSize(), 100);
    const onResize = () => map.invalidateSize();
    window.addEventListener('resize', onResize);
    return () => {
      clearTimeout(t);
      window.removeEventListener('resize', onResize);
    };
  }, [map]);
  return null;
}

export default function SupplyChainMap({ selected, onSelect, closed, routes = fallbackCorridors, sites = fallbackSites }) {
  const isClosed = (id) => Array.isArray(closed) ? closed.includes(id) : closed === id;
  return (
    <div className="map real-map">
      <MapContainer center={[18, 52]} zoom={3} scrollWheelZoom className="leaflet-map">
        <FixMapSize />
        {/* Switched off tile.openstreetmap.org -- direct hotlinking from an
            app isn't permitted by OSM's tile usage policy and gets blocked,
            which is what was showing as the oversized colored block. Carto's
            basemap is built from OSM data but is fine to embed, and the dark
            style matches this UI's theme. */}
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        />
        {routes.map((r) => (
          <Polyline
            key={r.id}
            positions={r.coords}
            pathOptions={{
              color: isClosed(r.id) ? '#64748b' : riskColor(r.risk),
              weight: selected?.id === r.id ? 8 : 5,
              opacity: 1,
              dashArray: isClosed(r.id) ? '10 8' : undefined,
            }}
            eventHandlers={{ click: () => onSelect(r) }}
          >
            <Popup>
              <b>{r.name}</b>
              <br />
              {Math.round(r.risk * 100)}% risk · {r.oil}
            </Popup>
          </Polyline>
        ))}
        {sites.map((s) => (
          <CircleMarker
            key={s.name}
            center={s.coords}
            radius={s.type === 'refinery' ? 7 : 6}
            pathOptions={{ color: colors[s.type], fillColor: colors[s.type], fillOpacity: 1 }}
          >
            <Popup>
              <b>{s.name}</b>
              <br />
              {s.type}
            </Popup>
          </CircleMarker>
        ))}
      </MapContainer>
      <div className="map-tip">Interactive OpenStreetMap · click a corridor or marker {closed && '· dashed = closed'}</div>
    </div>
  );
}