import { riskColor } from '../../utils/mapConfig';
export default function RouteLine({route,selected,closed,onClick}) { return <polyline points={route.points} onClick={()=>onClick(route)} fill="none" stroke={closed?'#64748b':riskColor(route.risk)} strokeWidth={selected?8:5} strokeDasharray={closed?'10 7':''} className="route"/>; }
